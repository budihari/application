<div>
         <div id="biodata" class="center" style="min-width: 120px; padding:12px; display: inline-block;">
            <a class="link-profil" href="<?= base_url();?>home/profil"><span class="nopadding bariol-regular">personal info</span></a>
         </div>
         <div id="shipping" class="center" style="min-width: 120px; padding:12px; display: inline-block; color:#0af;">
            <a class="link-profil" href="<?= base_url();?>home/shipping"><span class="nopadding bariol-regular">shipping option</span></a>
         </div>
         <div id="pass" class="center" style="min-width: 120px; padding:12px; display: inline-block;">
            <a class="link-profil" href="<?= base_url();?>home/password"><span class="nopadding bariol-regular">change password</span></a>
         </div>
         <div id="order" class="center" style="min-width: 120px; padding:12px; display: inline-block;">
            <a class="link-profil" href="<?= base_url();?>home/transaksi"><span class="nopadding bariol-regular">order history</span></a>
         </div>
         <div id="payment" class="center" style="min-width: 120px; padding:12px; display: inline-block;">
            <a class="link-profil" href="<?= base_url();?>payment"><span class="nopadding bariol-regular">payment history</span></a>
         </div>
      </div>