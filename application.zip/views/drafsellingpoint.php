<div class="sell">
<div class="left-sell inline-block" style="vertical-align: middle;">
    <img class="full" style="max-width: 100%;" src="<?= base_url(); ?>selingpoint/sh-233/sh-233.PNG" alt="">
</div>
<div class="right-sell inline-block" style="vertical-align: middle;">
<h3 style="font-style: italic; font-family: bariol_light;">OUR RELENTLESS COMMITMENT<br>
TO DESIGN & QUALITY</h3>
<p style="padding: 6px 12px; color: #0af;">SHALLOW WATER PUMP SH-233PAT</p>
<div style="padding: 12px;">
    <div class="inline-block width49">
        <div class="img-sell">
            <img style="max-width: 100%;" src="<?= base_url(); ?>selingpoint/sh-233/copper.PNG" alt="">
        </div>
        <div class="text-sell">
            <p><span>it’s 100% copper</span><br>
            motor dibuat dari lilitan tembaga murni,
            sehingga motor lebih tahan lama dan
            menghasilkan perfoma yang lebih baik</p>
        </div>
    </div>

    <div class="inline-block width49">
        <div class="img-sell">
            <img style="max-width: 100%;" src="<?= base_url(); ?>selingpoint/sh-233/keepitgoing.PNG" alt="">
        </div>
        <div class="text-sell">
            <p><span>keep it going 24/7</span><br>
            seluruh model pompa kami, dites dengan
            pengoprasian 24 jam non-stop</p>
        </div>
    </div>
    <div class="inline-block width49">
        <div class="img-sell">
            <img style="max-width: 100%;" src="<?= base_url(); ?>selingpoint/sh-233/resistancepaint.PNG" alt="">
        </div>
        <div class="text-sell">
            <p><span>rust resistance paint</span><br>
            badan pompa yang dilapisi dengan cat
            tahan karat, dapat mengurangi resiko
            kontaminasi air</p>
        </div>
    </div>
    
    <div class="inline-block width49">
        <div class="img-sell">
            <img style="max-width: 100%;" src="<?= base_url(); ?>selingpoint/sh-233/over-heatprotection.PNG" alt="">
        </div>
        <div class="text-sell">
            <p><span>over-heat protection</span><br>
            melindungi motor atau menghentikan
            motor secara otomatis apabila terjadi
            panas/over-heat</p>
        </div>
    </div>

    <div class="inline-block width49">
        <div class="img-sell">
            <img style="max-width: 100%;" src="<?= base_url(); ?>selingpoint/sh-233/brass.PNG" alt="">
        </div>
        <div class="text-sell">
            <p><span>brass casing liner</span><br>
            memiliki akurasi tinggi, tahan terhadap
            karat dan tahan terhadap gesekan
            sehingga menambah masa pakai pompa</p>
        </div>
    </div>
    
    <div class="inline-block width49">
        <div class="img-sell">
            <img style="max-width: 100%;" src="<?= base_url(); ?>selingpoint/sh-233/3yearswarranty.PNG" alt="">
        </div>
        <div class="text-sell">
            <p><span>3 years warranty</span><br>
            bahan yang berkualitas dan desain motor
            yang tepat memastikan motor akan berjalan
            minimal 3 tahun</p>
        </div>
    </div>

    <div class="inline-block width49">
        <div class="img-sell">
            <img style="max-width: 100%;" src="<?= base_url(); ?>selingpoint/sh-233/membrane.PNG" alt="">
        </div>
        <div class="text-sell">
            <p><span>membrane pressure tank (auto)</span><br>
            pressure tank kualitas tinggi dengan karet bladder
            butyl yang elastis untuk menjaga tekanan dalam
            pompa tetap stabil dan tahan lama</p>
        </div>
    </div>
    
    <div class="inline-block width49">
        <div class="img-sell">
            <img style="max-width: 100%;" src="<?= base_url(); ?>selingpoint/sh-233/pressureswitch.PNG" alt="">
        </div>
        <div class="text-sell">
            <p><span>pressure switch (auto)</span><br>
            pressure switch teknologi jepang menggunakan
            contact perak dan telah lulus uji coba lebih dari
            1 juta kali non-stop</p>
        </div>
    </div>
</div>
</div>
</div>