<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="x_panel">
   <div class="x_title">
      <h2>Managemen User</h2>
     <div class="clearfix"></div>
   </div>

   <div class="x_content">
      <table class="table table-striped table-bordered dt-responsive nowrap" id="datatable">
         <thead>
            <tr>
               <th width="8%">#</th>
               <th width="40%">Username</th>
               <th width="40%">Alamat</th>
               <th>Telp</th>
               <th>Status</th>
               <th>Opsi</th>
            </tr>
         </thead>
         <tbody>
         </tbody>
      </table>
      <p class="help-text">* Button active untuk menonaktifkan user, button non active untuk mengaktifkan user</p>
   <div>
      <a href="user/subscriber" class="btn btn-primary">Lihat data subscriber</a>
      <a href="user/pesan" class="btn btn-primary">Lihat pesan yg masuk</a>
   </div>
   </div>
</div>
