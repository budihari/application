<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>404 Page Not Found</title>
<style>
    
</style>
</head>
<body>
	<div style="min-height: 400px; background: #fff; display: flex;">
	<div style="margin:auto; background: #fff; width: 80%; height: 100px; text-align: center;">
		<p>Oops...Halaman tidak ditemukan</p>
		<p>:(</p>
		<button type='button' onclick='window.history.back()'>Kembali ke halaman sebelumnya</button>
	</div>
</div>
</body>
</html>