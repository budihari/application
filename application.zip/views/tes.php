<script>
$(document).ready(function(){
  $("button").click(function(){
    $("#div1").load("index.asp");
  });
});
</script>